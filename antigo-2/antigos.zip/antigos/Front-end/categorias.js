// let htmlOriginalDaPagina = '';

// document.addEventListener("DOMContentLoaded", () => {
//     const telaPrincipal = document.querySelector('main') || document.getElementById('conteudo-principal');
//     if (telaPrincipal) {
//         htmlOriginalDaPagina = telaPrincipal.innerHTML;
//     }
// });

// // 🟢 ADICIONE ESTA NOVA FUNÇÃO: Restaura a tela inicial quando chamada
// function voltarParaInicio(event) {
//     if (event) event.preventDefault();
    
//     const telaPrincipal = document.querySelector('main') || document.getElementById('conteudo-principal');
//     if (telaPrincipal && htmlOriginalDaPagina) {
//         telaPrincipal.innerHTML = htmlOriginalDaPagina;
        
//         // Rola a tela de volta para o topo suavemente
//         window.scrollTo({ top: 0, behavior: 'smooth' });
//     }
// }

// async function categorias(termo) {
//     if (!termo) {
//         console.error("Nenhum termo de busca foi fornecido.");
//         return;
//     }

//     const dadosParaEnviar = {
//         nomeProduto: termo
//     };

//     // 1. Localiza o corpo principal do site (Tag <main>)
//     const telaPrincipal = document.querySelector('main');
    
//     if (!telaPrincipal) {
//         // Fallback caso você tenha usado uma div com id em vez da tag main
//         const fallback = document.getElementById('conteudo-principal');
//         if (!fallback) {
//             console.error("Não foi possível encontrar a tag <main> ou o ID 'conteudo-principal' no seu HTML.");
//             return;
//         }
//     }

//     // Alvo final será a tag main encontrada
//     const alvoJanela = telaPrincipal || document.getElementById('conteudo-principal');

//     // 2. APAGA a página inicial e monta o título junto com o container estilizado do seu CSS (.vitrine-produtos)
//     alvoJanela.innerHTML = `
//         <div class="categorias" style="width: 100%; text-align: center; margin-bottom: 20px;">
//             <div class="text-final">
//                 <section>
//                     <h2 style="margin-top: 2vh;">Resultados para: <span style="color: var(--blue-escuro);">Eletronicos</span></h2>
//                 </section>
//             </div>
//         </div>
//         <div id="container-produtos" class="vitrine-produtos">
//             <p style="text-align: center; width: 100%; opacity: 0.7;">Buscando produtos na API...</p>
//         </div>
//     `;

//     try {
//         // 3. Faz a requisição para a API do ngrok
//         const resposta = await fetch('/api/categoria', {
//             method: 'POST',
//             headers: {
//                 'Content-Type': 'application/json',
//                 'ngrok-skip-browser-warning': 'true'
//             },
//             body: JSON.stringify(dadosParaEnviar)
//         });

//         if (resposta.ok) {
//             const dadosRetornados = await resposta.json();
            
//             // Localiza o container de produtos injetado acima
//             const containerProdutos = document.getElementById('container-produtos');
//             if (!containerProdutos) return;

//             // Limpa o texto de carregamento
//             containerProdutos.innerHTML = ''; 

//             const listaProdutos = typeof dadosRetornados === 'string' ? JSON.parse(dadosRetornados) : dadosRetornados;

//             if (listaProdutos.length === 0) {
//                 containerProdutos.innerHTML = '<p style="text-align: center; width: 100%; opacity: 0.5;">Nenhum produto encontrado para esta categoria.</p>';
//                 return;
//             }

//             // 4. Mapeia e desenha os cards respeitando INTEGRALMENTE as classes do seu CSS
//             listaProdutos.forEach(lista => {
//                 const divProduto = document.createElement('div');
//                 divProduto.classList.add('card-produto'); // Sua classe CSS da linha 212
//                 divProduto.style.position = 'relative'; // necessário pro coração ficar no canto

//                 const imagens = lista.imagem;
//                 const iconImagem = lista.Icon_loja;
//                 const nomeLoja = lista.loja;
//                 const titulo = lista.title;
//                 const preco = lista.preco;
//                 const linkProduto = lista.link;
//                 const nota_produto = lista.nota;
//                 const compras_total = lista.compras;

//                 // Montagem da estrutura de tags idêntica à esperada pelo seu CSS
//                 divProduto.innerHTML = `
//                     <button type="button" class="btn-favoritar"
//                         data-titulo="${(titulo || '').replace(/"/g, '&quot;')}"
//                         data-imagem="${imagens || ''}"
//                         data-preco="${preco || ''}"
//                         data-loja="${(nomeLoja || '').replace(/"/g, '&quot;')}"
//                         data-link="${linkProduto || ''}"
//                         style="position:absolute; top:8px; right:8px; border:none; background:rgba(255,255,255,0.85); border-radius:50%; width:32px; height:32px; font-size:16px; cursor:pointer;">🤍</button>

//                     <img src="${imagens}" alt="${titulo}" class="produto-img">
                    
//                     <div class="marca-container">
//                         <img src="${iconImagem}" alt="${nomeLoja}" class="loja-logo">
//                         <span class="produto-loja">${nomeLoja}</span>
//                     </div>
                    
//                     <h3 class="produto-titulo" style="font-size: 16px; margin: 8px 0; text-align: left;">${titulo}</h3>
                    
//                     <p class="esrelas" style="font-size: 13px; margin-bottom: 5px; text-align: left;">⭐ ${nota_produto}</p>
                    
//                     <p class="produto-preco" style="font-weight: bold; color: var(--blue-escuro); margin-bottom: 10px; text-align: left;">R$ ${preco}</p>
                    
//                     <a href="${linkProduto}" target="_blank" class="produto-link" style="
//                         display: block; 
//                         text-align: center; 
//                         background-color: var(--blue-escuro); 
//                         color: white; 
//                         text-decoration: none; 
//                         padding: 8px; 
//                         border-radius: 5px; 
//                         font-size: 14px;
//                         margin-top: auto;
//                     ">Ver na Loja</a>
                    
//                     <p class="total_de_compras" style="font-size: 11px; opacity: 0.6; text-align: center; margin-top: 5px;">Total: ${compras_total}</p>
//                 `;
               
//                 containerProdutos.appendChild(divProduto);
//             });

//             // Faz a tela rolar suavemente até o topo da nova listagem de produtos
//             containerProdutos.scrollIntoView({ behavior: 'smooth' });

//         } else {
//             document.getElementById('container-produtos').innerHTML = '<p style="text-align: center; color: red;">Erro ao responder ao servidor.</p>';
//         }

//     } catch (erro) {
//         console.error('Erro na conexão ao buscar API:', erro);
//         const container = document.getElementById('container-produtos');
//         if (container) {
//             container.innerHTML = '<p style="text-align: center; opacity: 0.7;">Servidor com problemas, tente novamente mais tarde...</p>';
//         }
//     }
// }

// ===== PÁGINA INICIAL / CATEGORIAS =====

let htmlOriginalDaPagina = '';

function areaPrincipal() {
    return document.querySelector('main') || document.getElementById('conteudo-principal');
}

document.addEventListener('DOMContentLoaded', () => {
    const telaPrincipal = areaPrincipal();
    if (telaPrincipal) {
        htmlOriginalDaPagina = telaPrincipal.innerHTML;
    }
});

// Restaura a tela inicial (usado pela logo e pelo botão "início")
function voltarParaInicio(event) {
    if (event) event.preventDefault();

    const telaPrincipal = areaPrincipal();
    if (telaPrincipal && htmlOriginalDaPagina) {
        telaPrincipal.innerHTML = htmlOriginalDaPagina;
        window.scrollTo({ top: 0, behavior: 'smooth' });
    }
}

// Mostra a vitrine de eletrônicos
async function categorias(event) {
    if (event && event.preventDefault) event.preventDefault();

    const alvoJanela = areaPrincipal();
    if (!alvoJanela) {
        console.error("Não foi possível encontrar a tag <main> no HTML.");
        return;
    }

    alvoJanela.innerHTML = `
        <div class="categorias" style="width: 100%; text-align: center; margin-bottom: 20px;">
            <div class="text-final">
                <section>
                    <h2 style="margin-top: 2vh;">Categoria: <span style="color: var(--blue-escuro);">Eletrônicos</span></h2>
                </section>
            </div>
        </div>
        <div id="container-produtos" class="vitrine-produtos">
            <p style="text-align: center; width: 100%; opacity: 0.7;">Buscando produtos...</p>
        </div>
    `;

    const container = document.getElementById('container-produtos');

    try {
        const resposta = await fetch('/api/categoria', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({})
        });

        const dados = await resposta.json().catch(() => null);

        if (!resposta.ok) {
            const msg = (dados && dados.erro) || 'Erro ao responder ao servidor.';
            container.innerHTML = `<p style="text-align: center; width: 100%; color: #c0392b;">${escapeHTML(msg)}</p>`;
            return;
        }

        const listaProdutos = Array.isArray(dados) ? dados : [];
        container.innerHTML = '';

        if (listaProdutos.length === 0) {
            container.innerHTML = '<p style="text-align: center; width: 100%; opacity: 0.5;">Nenhum produto encontrado para esta categoria.</p>';
            return;
        }

        listaProdutos.forEach((item) => {
            container.appendChild(criarElementoCard(item, { modo: 'busca' }));
        });

        container.scrollIntoView({ behavior: 'smooth' });

    } catch (erro) {
        console.error('Erro na conexão ao buscar API:', erro);
        container.innerHTML = '<p style="text-align: center; width: 100%; opacity: 0.7;">Servidor com problemas, tente novamente mais tarde...</p>';
    }
}


