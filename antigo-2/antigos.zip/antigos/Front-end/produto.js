// // 1. Criamos a função das categorias totalmente isolada
// function criarSecaoCategorias() {
//     // Limpa o container de categorias antes de criar para não duplicar se pesquisar de novo
//     const containerCategorias = document.getElementById('icategorias');
//     containerCategorias.innerHTML = '';

//     const text = document.createElement('section');
//     text.classList.add('text-final');
    
//     text.innerHTML = `
//         <h2>Melhores resultados encontrados</h2>
//         <p>Confira os modelos disponíveis nas lojas encontradas!</p>
//     `;
    
//     containerCategorias.appendChild(text);
// }
 
          


// async function Produto_cliente() {
//     const produto = document.getElementById('Produtos');
    

//     const valor = produto.value;


//     const dadosParaEnviar = {
//         nomeProduto: valor
//     };

//     try {
//         const resposta = await fetch('/api/produtos', {
//             method: 'POST',
//             headers: {
//                 'Content-Type': 'application/json', // C maiúsculo corrigido
//                 'ngrok-skip-browser-warning': 'true'
//             },
//             body: JSON.stringify(dadosParaEnviar)
//         });

//         if (resposta.ok) {

//             document.getElementById('container-produtos').innerHTML='';

//             const dadosRetornados = await resposta.json();
//             console.log('Sucesso:', dadosRetornados);

            

//             const listaProdutos = typeof dadosRetornados === 'string' ? JSON.parse(dadosRetornados) : dadosRetornados;



//             listaProdutos.forEach(lista => {
//                 // Colocando nas Variaveis

//                  const divProduto = document.createElement('div');
                 
//                 // Se você tiver uma lista global acumulando os produtos, zere ela:
                
               
//                 divProduto.classList.add('card-produto');
//                 divProduto.style.position = 'relative'; // necessário pro coração ficar no canto
                
//                 // Classe CSS para estilizar depois

//                 // const posicao = dadosRetornados.posicao;
//                 // const iconLoja = dadosRetornados.Icon_loja;
//                 // const title = dadosRetornados.title;
//                 // const preco = dadosRetornados.preco;
//                 // const loja = dadosRetornados.loja;
//                 // const link = dadosRetornados.link;


//                 const imagens = lista.imagem;
//                 const iconImagem = lista.Icon_loja;
//                 const nomeLoja = lista.loja;
//                 const titulo = lista.title;
//                 const preco = lista.preco;
//                 const linkProduto = lista.link;
//                 const nota_produto = lista.nota;
//                 const compras_total = lista.compras


               

//                  divProduto.innerHTML = `
//                     <button type="button" class="btn-favoritar"
//                         data-titulo="${(titulo || '').replace(/"/g, '&quot;')}"
//                         data-imagem="${imagens || ''}"
//                         data-preco="${preco || ''}"
//                         data-loja="${(nomeLoja || '').replace(/"/g, '&quot;')}"
//                         data-link="${linkProduto || ''}"
//                         style="position:absolute; top:8px; right:8px; border:none; background:rgba(255,255,255,0.85); border-radius:50%; width:32px; height:32px; font-size:16px; cursor:pointer;">🤍</button>

//                     <img src="${imagens}" alt="${titulo}" class="produto-img">
//                     <div class="produto-info">
//                         <div class="marca-container">
//                             <img src="${iconImagem}" alt="Logo" ${nomeLoja} class="loja-logo">
//                             <span class="produto-loja">${nomeLoja}</span>
//                         </div>
//                         <h3 class="produto-titulo">${titulo}</h3>
//                         <p class="esrelas">Avaliação: ⭐ ${nota_produto}</p>

//                         <p class="produto-preco">R$ ${preco}</p>
//                         <a href="${linkProduto}" target="_blank" class="produto-link">Ver na Loja</a>
//                         <p class="total_de_compras">total:${compras_total}</p>
//                     </div>
//                 `;
               
//                  document.getElementById('container-produtos').appendChild(divProduto);
                 
//                  document.getElementById('icategorias').scrollIntoView({
//                     behavior: 'smooth', // rolagem suave (em vez de instantânea)
//                     block: 'start'      // alinha o topo do elemento com o topo da viewport
//                     });
                
//             });

//             criarSecaoCategorias();
//         } // <- Fecha o if (resposta.ok)

//     } catch (erro) { // <- O catch agora está conectado corretamente ao try
//         console.error('Erro na conexão ao buscar API:', erro);
//     }
// } // <- Fecha a função Produto_cliente


// function create_cont(event){
//       event.preventDefault();
//         window.location.href = 'Front-end/create_user.html'
// }


// function entrar(event){
//       event.preventDefault();
//     window.location.href = 'Front-end/entrar.html'
// }


// function entrar(event){
//       event.preventDefault();
//     window.location.href = 'Front-end/entrar.html'
// }

// ===== BUSCA DE PRODUTOS (página inicial) =====

function criarSecaoCategorias() {
    // Limpa o container antes de criar para não duplicar se pesquisar de novo
    const containerCategorias = document.getElementById('icategorias');
    if (!containerCategorias) return;
    containerCategorias.innerHTML = '';

    const text = document.createElement('section');
    text.classList.add('text-final');
    text.innerHTML = `
        <h2>Melhores resultados encontrados</h2>
        <p>Confira os modelos disponíveis nas lojas encontradas!</p>
    `;
    containerCategorias.appendChild(text);
}

let buscaEmAndamento = false;

async function Produto_cliente() {
    if (buscaEmAndamento) return; // evita clique duplo gastando a cota da API

    const campo = document.getElementById('Produtos');
    const botao = document.querySelector('.inputs .resultado');
    const container = document.getElementById('container-produtos');
    if (!campo || !container) return;

    const valor = campo.value.trim();

    if (valor.length < 2) {
        window.alert('Digite o nome de um produto (mínimo 2 letras).');
        campo.focus();
        return;
    }

    buscaEmAndamento = true;
    if (botao) { botao.disabled = true; botao.value = 'Buscando...'; }
    container.innerHTML = '<p style="text-align:center; width:100%; opacity:0.7;">Buscando preços...</p>';

    try {
        const resposta = await fetch('/api/produtos', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ nomeProduto: valor })
        });

        const dados = await resposta.json().catch(() => null);

        if (!resposta.ok) {
            const msg = (dados && dados.erro) || 'Não foi possível buscar agora. Tente novamente.';
            container.innerHTML = `<p style="text-align:center; width:100%; color:#c0392b;">${escapeHTML(msg)}</p>`;
            return;
        }

        const listaProdutos = Array.isArray(dados) ? dados : [];

        criarSecaoCategorias();
        container.innerHTML = '';

        if (listaProdutos.length === 0) {
            container.innerHTML = '<p style="text-align:center; width:100%; opacity:0.6;">Nenhum produto encontrado. Tente outro nome.</p>';
            return;
        }

        listaProdutos.forEach((item) => {
            container.appendChild(criarElementoCard(item, { modo: 'busca' }));
        });

        // rola até os resultados uma vez só (antes rolava a cada produto)
        document.getElementById('icategorias').scrollIntoView({ behavior: 'smooth', block: 'start' });

    } catch (erro) {
        console.error('Erro na conexão ao buscar API:', erro);
        container.innerHTML = '<p style="text-align:center; width:100%; opacity:0.7;">Sem conexão com o servidor. Tente novamente.</p>';
    } finally {
        buscaEmAndamento = false;
        if (botao) { botao.disabled = false; botao.value = 'Comparar preços'; }
    }
}

// Enter no campo de busca também pesquisa.
// (delegação no document: continua funcionando depois que a página inicial é restaurada)
document.addEventListener('keydown', function (event) {
    if (event.key === 'Enter' && event.target && event.target.id === 'Produtos') {
        event.preventDefault();
        Produto_cliente();
    }
});

function create_cont(event) {
    if (event) event.preventDefault();
    window.location.href = 'Front-end/create_user.html';
}

function entrar(event) {
    if (event) event.preventDefault();
    window.location.href = 'Front-end/entrar.html';
}
